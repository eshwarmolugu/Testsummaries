package unittests;

import org.junit.Assert;
import org.junit.Test;

public class PPMUnit2Test {

	
    @Test 
    public void test1() { 
        Assert.assertTrue(true);
    }

}
