package unittests;

import org.junit.Assert;
import org.junit.Test;

public class PPMUnit3Test {
    @Test 
    public void test1() { 
        Assert.assertTrue(true);
    }

}
