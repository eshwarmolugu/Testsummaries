package ppmtests;

import org.junit.Assert;
import org.junit.Test;

public class PPMSample2Test {

	
    @Test 
    public void test1() { 
        Assert.assertTrue(true);
    }

}
