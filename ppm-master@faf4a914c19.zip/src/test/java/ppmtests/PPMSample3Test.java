package ppmtests;

import org.junit.Assert;
import org.junit.Test;

public class PPMSample3Test {
    @Test 
    public void test1() { 
        Assert.assertTrue(true);
    }

}
